<?php

namespace App\Livewire\Kader;

use App\Models\Kader;
use Livewire\Component;

class FormCekKinerjaKader extends Component
{

    public function render()
    {
        return view('livewire.kader.form-cek-kinerja-kader');
    }
}
