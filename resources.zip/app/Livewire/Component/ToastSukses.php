<?php

namespace App\Livewire\Component;

use Livewire\Component;

class ToastSukses extends Component
{
    public function render()
    {
        return view('livewire.component.toast-sukses');
    }
}
