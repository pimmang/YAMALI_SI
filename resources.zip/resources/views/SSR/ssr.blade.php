@extends('layouts.main')
@section('main')
    @livewire('Ssr.ssr')
@endsection
