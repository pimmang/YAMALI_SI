@extends('layouts.main')
@section('main')
    <livewire:tb-so.ternotifikasi.ternotifikasi />
@endsection
