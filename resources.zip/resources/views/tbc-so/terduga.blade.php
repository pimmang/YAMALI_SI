@extends('layouts.main')
@section('main')
    <livewire:tb-so.terduga.terduga />
@endsection
