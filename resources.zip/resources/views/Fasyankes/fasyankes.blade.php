@extends('layouts.main')
@section('main')
    @livewire('fasyankes.fasyankes')
@endsection
