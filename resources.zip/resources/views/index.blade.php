@extends('layouts.main')
@section('main')
    @livewire('index.list-index')
@endsection
