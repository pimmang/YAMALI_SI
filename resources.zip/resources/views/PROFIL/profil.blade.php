@extends('layouts.main')
@section('main')
    <livewire:profil.profil />
@endsection
