@extends('layouts.main')
@section('main')
    <p>{{ $status }}</p>
@endsection
