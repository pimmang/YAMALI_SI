<div class="w-full flex items-center justify-between  gap-6">
    <div id="date-range-picker" date-rangepicker class="flex items-center">
        <div class="relative">
            <div class="absolute inset-y-0 start-0 flex items-center ps-3 pointer-events-none">
                <svg class="w-4 h-4 text-gray-500 dark:text-gray-400" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"
                    fill="currentColor" viewBox="0 0 20 20">
                    <path
                        d="M20 4a2 2 0 0 0-2-2h-2V1a1 1 0 0 0-2 0v1h-3V1a1 1 0 0 0-2 0v1H6V1a1 1 0 0 0-2 0v1H2a2 2 0 0 0-2 2v2h20V4ZM0 18a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V8H0v10Zm5-8h10a1 1 0 0 1 0 2H5a1 1 0 0 1 0-2Z" />
                </svg>
            </div>
            <input id="datepicker-range-start" name="start" type="text" wire:model='dateStart'
                class="bg-white border-none  text-gray-900 text-xs rounded-lg focus:ring-orange-500 block w-full ps-10 p-2.5  shadow"
                placeholder="Pilih tanggal mulai">
        </div>
        <span class="mx-4 text-gray-700 font-medium">to</span>
        <div class="relative">
            <div class="absolute inset-y-0 start-0 flex items-center ps-3 pointer-events-none">
                <svg class="w-4 h-4 text-gray-500 dark:text-gray-400" aria-hidden="true"
                    xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 20 20">
                    <path
                        d="M20 4a2 2 0 0 0-2-2h-2V1a1 1 0 0 0-2 0v1h-3V1a1 1 0 0 0-2 0v1H6V1a1 1 0 0 0-2 0v1H2a2 2 0 0 0-2 2v2h20V4ZM0 18a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V8H0v10Zm5-8h10a1 1 0 0 1 0 2H5a1 1 0 0 1 0-2Z" />
                </svg>
            </div>
            <input id="datepicker-range-end" name="end" type="text" wire:model='dateEnd'
                class="bg-white border-none  text-gray-900 text-xs rounded-lg focus:ring-orange-500 block w-full ps-10 p-2.5  shadow"
                placeholder="Pilih tanggal akhir">
        </div>
    </div>


    <div class="flex items-center flex-grow">
        <label for="simple-search" class="sr-only">Search</label>
        <div class="relative w-full">
            <div class="absolute inset-y-0 start-0 flex items-center ps-3 pointer-events-none">
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="#6a6868"
                    viewBox="0 0 256 256">
                    <path
                        d="M96,104a8,8,0,0,1,8-8h64a8,8,0,0,1,0,16H104A8,8,0,0,1,96,104Zm8,40h64a8,8,0,0,0,0-16H104a8,8,0,0,0,0,16Zm128,48a32,32,0,0,1-32,32H88a32,32,0,0,1-32-32V64a16,16,0,0,0-32,0c0,5.74,4.83,9.62,4.88,9.66h0A8,8,0,0,1,24,88a7.89,7.89,0,0,1-4.79-1.61h0C18.05,85.54,8,77.61,8,64A32,32,0,0,1,40,32H176a32,32,0,0,1,32,32V168h8a8,8,0,0,1,4.8,1.6C222,170.46,232,178.39,232,192ZM96.26,173.48A8.07,8.07,0,0,1,104,168h88V64a16,16,0,0,0-16-16H67.69A31.71,31.71,0,0,1,72,64V192a16,16,0,0,0,32,0c0-5.74-4.83-9.62-4.88-9.66A7.82,7.82,0,0,1,96.26,173.48ZM216,192a12.58,12.58,0,0,0-3.23-8h-94a26.92,26.92,0,0,1,1.21,8,31.82,31.82,0,0,1-4.29,16H200A16,16,0,0,0,216,192Z">
                    </path>
                </svg>
            </div>
            <input type="text" id="simple-search" wire:model.live='cari'
                class="bg-white border-none  text-gray-900 text-sm rounded-lg focus:ring-orange-500 shadow block w-full ps-10 p-2.5  dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-orange-500 dark:focus:border-orange-500"
                placeholder="Cari nama, nik..." />
        </div>
        <button id="restart" wire:click='restart'
            class="px-2.5 py-1  ms-2 text-sm font-medium text-orange-500 shadow  border-orange-500 rounded-lg border-2  hover:bg-orange-300  hover:border-orange-300 ">
            <i class="ph-bold ph-arrow-counter-clockwise text-lg"></i>
        </button>
        <button id="submit" wire:click='submit'
            class="p-2.5 ms-2 text-sm font-medium text-white shadow bg-orange-500 rounded-lg border-2 border-orange-500  hover:bg-orange-300 hover:border-orange-300 ">
            <svg class="w-4 h-4" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none"
                viewBox="0 0 20 20">
                <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                    d="m19 19-4-4m0-7A7 7 0 1 1 1 8a7 7 0 0 1 14 0Z" />
            </svg>
            <span class="sr-only">Search</span>
        </button>

    </div>

    <script>
        const submit = document.getElementById('submit');
        const dateStart = document.getElementById('datepicker-range-start');
        const dateEnd = document.getElementById('datepicker-range-end');

        submit.onclick = masukanNilai;

        function masukanNilai() {
            dateStart.dispatchEvent(new Event('input'));
            dateEnd.dispatchEvent(new Event('input'));
        }

        console.log(dateEnd, dateStart);
    </script>



</div>
