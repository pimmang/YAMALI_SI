@extends('layouts.main')
@section('main')
    @livewire('ik-tpt-balita')
@endsection
