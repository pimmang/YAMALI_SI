@extends('layouts.main')
@section('main')
    @livewire('kader.kader')
@endsection
